library(tseries)
library(TSA)
library(rugarch)
library(forecast)

# Load the data and order by date
data = read.csv("C:/Users/andre/Documents/DatasetTimeSeries.csv")
data = data[order(data$Date), ]

# Prepare the cumulative average series
y = data[,1]
n = length(y)
y_avg = y
sum_y = y[1]

for(i in 2:n) {
  sum_y = sum_y + y[i]
  y_avg[i] = sum_y / i
}

y_avg = ts(y_avg)

# Define training data from 10 to 1500
y_train = ts(y_avg[10:1550])
y_actual <- ts(y_avg[1551:1688])

# Fit ARIMA model on the training data
fit_arima <- auto.arima(y_train)
summary(fit_arima)

# Forecast y_train for the period 1501 to 1688
forecast_result <- forecast(fit_arima, h = length(y_actual))
y_train_pred <- forecast_result$mean

# Prepare the time index for the forecasted period
forecast_time <- 1551:1688

# Plot the entire time series
plot(y_avg, col = "black", xlab = "Time", ylab = "y", main = "Actual and Forecasted Values")

# Plot the forecasted values for the test period
lines(forecast_time, y_train_pred, col = "red", lty = 2)  # Forecasted values

# Plot the actual values for the test period
lines(forecast_time, y_actual, col = "green", lty = 1)  # Actual values

# Add legend
legend("topleft", legend = c("Training Data", "Forecasted", "Actual"), col = c("blue", "red", "green"))

# Get residuals from the ARIMA model
residuals_arima <- residuals(fit_arima)

# Fit GARCH model to the residuals
garch_spec <- ugarchspec(variance.model = list(model = "sGARCH", garchOrder = c(2, 2)),
                         mean.model = list(armaOrder = c(0, 0), include.mean = FALSE), 
                         distribution.model = "norm")

garch_fit <- ugarchfit(spec = garch_spec, data = residuals_arima)

# Summarize the GARCH model fit
summary(garch_fit)

# Forecast volatility using the GARCH model
garch_forecast <- ugarchforecast(garch_fit, n.ahead = length(y_actual))

# Extract forecasted volatility (conditional standard deviation)
volatility_forecast <- as.numeric(garch_forecast@forecast$sigmaFor)

# Create the upper and lower bounds for the forecast
upper_forecast <- y_train_pred + 1.96 * volatility_forecast
lower_forecast <- y_train_pred - 1.96 * volatility_forecast

# Plot the forecast with confidence intervals
plot(y_avg, col = "black", xlab = "Time", ylab = "y", main = "Forecast with Confidence Intervals")
lines(10:1550, y_train, col = "blue", lty = 1)  # Training data
lines(forecast_time, y_train_pred, col = "red", lty = 2)  # Forecasted values
lines(forecast_time, y_actual, col = "green", lty = 1)  # Actual values
lines(forecast_time, upper_forecast, col = "orange", lty = 2)  # Upper bound
lines(forecast_time, lower_forecast, col = "orange", lty = 2)  # Lower bound

# Add legend
legend("topleft", legend = c("Training Data", "Forecasted", "Actual", "Confidence Interval"), 
       col = c("blue", "red", "green", "orange"), lty = c(1, 2, 1, 2))
