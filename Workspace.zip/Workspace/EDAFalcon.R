
library(dplyr)
library(ggplot2)
# Load the data and order by date
data = read.csv("C:/Users/andre/Documents/DatasetFalconEDAandModelling.csv")
summary(data)


travel <- table(data$Type.Of.Traveller)
percentages <- round(100 * travel / sum(travel), 1)

# Create labels with percentages
labels <- paste(names(travel), "\n", percentages, "%", sep="")

# Plot the pie chart with percentage labels
pie(travel, labels = labels, main = "Type of Traveller", col = rainbow(length(travel)))



seat <- table(data$Seat.Type)
percentages <- round(100 * seat / sum(seat), 1)

# Create labels with percentages
labels <- paste(names(seat), "\n", percentages, "%", sep="")

# Plot the pie chart with percentage labels
pie(seat, labels = labels, main = "Type of Seats", col = rainbow(length(seat)))



recommend <- table(data$Recommended)
percentages <- round(100 * recommend / sum(recommend), 1)

# Create labels with percentages
labels <- paste(names(recommend), "\n", percentages, "%", sep="")

# Plot the pie chart with percentage labels
pie(recommend, labels = labels, main = "Recommended or Not", col = rainbow(length(recommend)))


Continents <- table(data$Continent)
percentages <- round(100 * Continents / sum(Continents), 1)

# Create labels with percentages
labels <- paste(names(Continents), "\n", percentages, "%", sep="")

# Plot the pie chart with percentage labels
pie(Continents, labels = labels, main = "Continents", col = rainbow(length(Continents)))


hist(data$Rating, main="Rating Dist.")
hist(data$Month, main="Months Dist.")

data$Category <- ifelse(data$Rating > 7, "Good",
                        ifelse(data$Rating >= 5, "Neutral", "Bad"))

category <- table(data$Category)
percentages <- round(100 * category / sum(category), 1)

# Create labels with percentages
labels <- paste(names(category), "\n", percentages, "%", sep="")

# Plot the pie chart with percentage labels
pie(category, labels = labels, main = "Rating", col = rainbow(length(category)))


#############################################
#TYPE OF TRAVELLER
ggplot(data, aes(x = Type.Of.Traveller, y = Rating)) +
  geom_boxplot(fill = "lightblue", color = "black") +
  labs(title = "Boxplot of Ratings by Travel Type",
       x = "Travel Type", y = "Rating") +
  theme_minimal()

ggplot(data, aes(x = Type.Of.Traveller, fill = Recommended)) +
  geom_bar(position = "dodge") +
  labs(title = "Frequency of Travel Types by Recommendation",
       x = "Travel Type", 
       y = "Count", 
       fill = "Recommended") +
  theme_minimal()

result <- data %>%
  group_by(Type.Of.Traveller) %>%
  summarise(Average_Rating = mean(Rating))
print(result)


traveler_table <- table(data$Type.Of.Traveller, data$Recommended)

# Calculate the proportion of 'Yes' recommendations based on the type of traveler
traveler_proportion <- prop.table(traveler_table, 1)[, 'Yes']

# Print the result
print(traveler_proportion)

#SEAT TYPES
ggplot(data, aes(x = Seat.Type, y = Rating)) +
  geom_boxplot(fill = "lightblue", color = "black") +
  labs(title = "Boxplot of Ratings by Seat Type",
       x = "Seat Type", y = "Rating") +
  theme_minimal()

ggplot(data, aes(x = Seat.Type, fill = Recommended)) +
  geom_bar(position = "dodge") +
  labs(title = "Frequency of Seat Types by Recommendation",
       x = "Travel Type", 
       y = "Count", 
       fill = "Recommended") +
  theme_minimal()

result <- data %>%
  group_by(Seat.Type) %>%
  summarise(Average_Rating = mean(Rating))
print(result)

seat_table <- table(data$Seat.Type, data$Recommended)

# Calculate the proportion of 'Yes' recommendations based on the type of traveler
seat_proportion  <- prop.table(seat_table, 1)[, 'Yes']

# Print the result
print(seat_proportion)


data$Continent

#CONTINENTS
ggplot(data, aes(x = Continent, y = Rating)) +
  geom_boxplot(fill = "lightblue", color = "black") +
  labs(title = "Boxplot of Ratings by Continents",
       x = "Continents", y = "Rating") +
  theme_minimal()

ggplot(data, aes(x = Continent, fill = Recommended)) +
  geom_bar(position = "dodge") +
  labs(title = "Frequency of Continents by Recommendation",
       x = "Continents", 
       y = "Count", 
       fill = "Recommended") +
  theme_minimal()


result <- data %>%
  group_by(Continent) %>%
  summarise(Average_Rating = mean(Rating))
print(result)

continent_table <- table(data$Continent, data$Recommended)

# Calculate the proportion of 'Yes' recommendations based on the type of traveler
continent_proportion  <- prop.table(continent_table, 1)[, 'Yes']


# Print the result
print(continent_proportion)

continent_table <- table(data$Continent, data$EncodeCategory)

# Calculate the proportion of 'Yes' recommendations based on the type of traveler
continent_table  <- prop.table(continent_table, 1)
print(continent_table)

